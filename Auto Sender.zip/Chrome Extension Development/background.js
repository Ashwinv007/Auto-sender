// Add an event listener to listen for messages from the popup
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === "Start_button_Clicked") {
    const baseUrls = message.urls; // Use the received 'urls' array
    const subUrls = ["/dbout", "/contact", "/#contact", "test-form/","send-req/","button-test/"];
    const activeUrls = [];
    const activeUrlsIndex = [];
    const failedUrls=[];
    let otherError = true;
    const messages = message.messages;
    const subjects = message.subjects;
    console.log('Messages received:', messages);
    console.log('Subjects received:', subjects);

    const fetchPromises = [];
    baseUrls.forEach((baseUrl) => {
      let urlMatched = false; // Flag to check if at least one suburl matches

      subUrls.forEach((subUrl) => {
        const fullUrl = `${baseUrl}${subUrl}`;
        fetchPromises.push(
          fetch(fullUrl)
            .then((response) => {
              if (response.status === 200) {

                console.log(baseUrls.indexOf(baseUrl))
                console.log(baseUrl)
                activeUrlsIndex.push(baseUrls.indexOf(baseUrl))
                activeUrls.push(fullUrl);
                urlMatched = true; // Set the flag to true since at least one suburl matched

                
              } else {
                console.log(`Not Found: ${fullUrl}`);

              }
            })
            .catch((error) => {
              console.log("Error:", error);
            })
        );
      });
      
      Promise.all(fetchPromises)
      .then(() => {
        // Check if at least one suburl matched, if not, consider it a failure
        if (!urlMatched) {
          console.log(`No suburl matched for base URL: ${baseUrl}`);
          failedUrls.push(baseUrl);
        }
      });
    });

    // Use Promise.all to wait for all fetch requests to complete
    Promise.all(fetchPromises)
      .then(() => {

        console.log(activeUrls);
        console.log(activeUrlsIndex)
        console.log(failedUrls)
        for (var i = 0; i < failedUrls.length; i++) {
          handleFailedUrl(failedUrls[i]);
      }



        function synchronousOpenUrlsAndClose () {
          let index = 0;

          
        let pauseExtension = false;
          function openNextUrl() {
            
            if (index < activeUrls.length) {
              if(!pauseExtension){

              
              // Print the URL
              console.log(activeUrls[index]);
              console.log(index)
        
              // Console "Hello"
              console.log('Hello');
        
              chrome.windows.create({
                url: activeUrls[index],
                type: "normal",
                width: 800,
                height: 600,
                left: 100,
                top: 100,
                focused: true,
              })
                .then((newWindow) => {
                  const tabId = newWindow.tabs[0].id;
                  console.log(tabId)

                  let currentURLDataIndex = activeUrlsIndex[index]
                  // console.log(messages[currentURLDataIndex])
                  // console.log(subjects[currentURLDataIndex])
                  chrome.runtime.onMessage.addListener(
                    function (request, sender, sendResponse) {
                      if (request.action === "resetExtension") {
                        // Clear chrome.local.storage
                        chrome.storage.local.clear();
                  
                      
                  
                        chrome.runtime.reload();
                      }
                    }
                  );
                  // console.log(subjects[currentURLDataIndex])
                  chrome.runtime.onMessage.addListener(
                    function (request, sender, sendResponse) {
                      if (request.action === "pauseExtension") {
                        // Clear chrome.local.storage
                       pauseExtension = true;
                      }

                      if (request.action === "resumeButton") {
                        // Clear chrome.local.storage
                       pauseExtension = false;
                       openNextUrl();
                      }
                    }
                  );
                  
                  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
                    if (message.action === "rePassData") {
                        // Handle the "rePassData" message
                  
                       
                  
                       
                                // Send a message after a 5-second delay
                                
                                setTimeout(function () {
                                    chrome.tabs.sendMessage(tabId, {
                                        action: "PassData",
                                        message: messages[currentURLDataIndex],
                                        subject: subjects[currentURLDataIndex],
                                        limiter:true
                                    });
                                }, 3000);
                            }
                          })
                  chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                    if (info.status === 'complete' && tabId === newWindow.tabs[0].id) {
                      chrome.tabs.onUpdated.removeListener(listener);
    
                      // Pass messages and subjects to content script
                      chrome.tabs.sendMessage(tabId, { action: "PassData", message: messages[currentURLDataIndex], subject: subjects[currentURLDataIndex],limiter:false
                    });
    
                  chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    files: ["content.js"],
                    
                    
                  });


        
                  // Wait for 10 seconds and then remove the window
                  setTimeout(() => {
                    chrome.tabs.remove(tabId, () => {
                      // Window removal is complete
                      // Continue to the next URL after removal
                      if(otherError){
                        handleFailedUrl(activeUrls[index])
                      }
                      index++;
                      setTimeout(openNextUrl, 2000); // Introduce a 2-second delay
                    });
                  }, 30000); // 10 seconds delay before removal
                }
                })
                })
                .catch((error) => {
                  console.error("Error creating window: " + error);
                  // Continue to the next URL in case of an error
                  if(otherError){
                    handleFailedUrl(activeUrls[index])
                  }
                  index++;
                  setTimeout(openNextUrl, 2000); // Introduce a 2-second delay
                });
              }else{
                console.log('Extension is Paused')
              }
            }

          }
        
          // Start the loop by calling openNextUrl for the first time
          openNextUrl();
        }
        
        synchronousOpenUrlsAndClose ();
        



       

          

      })
      .catch((error) => {
        console.log("Error in Promise.all:", error);
      })
  }
});
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "submitStatus") {

      var status = request.value ? "SENT" : "FAILED";
      var url = request.url;
      var issue = request.issue;

      if(request.value===true){
        otherError=false;
      }

      if (issue) {
          var dataToStore = url + ',' + status + ',' + issue;
      } else {
          var dataToStore = url + ',' + status;
      }

      // Retrieve existing submissions from chrome.local storage
      chrome.storage.local.get({ submissions: [] }, function (result) {
          var submissions = result.submissions || [];

          // Check if the data already exists in the submissions array
          var isDuplicate = submissions.some(function (entry) {
            var entryUrl = entry.split(',')[0].trim();
            return entryUrl === url;          });

          // If it's not a duplicate, add the new data to the submissions array
          if (!isDuplicate) {
              submissions.push(dataToStore);

              // Update the chrome.local storage with the modified submissions array
              chrome.storage.local.set({ submissions: submissions }, function () {
                  console.log('Data stored in chrome.local storage:', dataToStore);
              });
          } else {
              console.log('Data is a duplicate and will not be stored:', dataToStore);
          }
      });
  }
});



function handleFailedUrl(failedUrl){
  var status = "FAILED";
      var url = failedUrl
      var issue = 'OTHER'

          var dataToStore = url + ',' + status + ',' + issue;
      

      // Retrieve existing submissions from chrome.local storage
      chrome.storage.local.get({ submissions: [] }, function (result) {
          var submissions = result.submissions || [];

          // Check if the data already exists in the submissions array
          var isDuplicate = submissions.some(function (entry) {
            var entryUrl = entry.split(',')[0].trim();
            return entryUrl === url;          });

          // If it's not a duplicate, add the new data to the submissions array
          if (!isDuplicate) {
              submissions.push(dataToStore);

              // Update the chrome.local storage with the modified submissions array
              chrome.storage.local.set({ submissions: submissions }, function () {
                  console.log('Data stored in chrome.local storage:', dataToStore);
              });
          } else {
              console.log('Data is a duplicate and will not be stored:', dataToStore);
          }
      });

}